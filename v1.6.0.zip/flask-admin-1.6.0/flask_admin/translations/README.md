Translations are ONLY handled through Crowdin!
https://crowdin.com/project/flask-admin
