``flask_admin.base``
====================

.. automodule:: flask_admin.base

    Base View
    ---------

    .. autofunction:: expose
    .. autofunction:: expose_plugview

    .. autoclass:: BaseView
        :members:

    Default view
    ------------

    .. autoclass:: AdminIndexView
        :members:

    Admin
    -----

    .. autoclass:: Admin
        :members:
