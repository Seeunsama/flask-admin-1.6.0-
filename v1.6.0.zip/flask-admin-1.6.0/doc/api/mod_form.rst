``flask_admin.form``
====================

.. automodule:: flask_admin.form

    .. autoclass:: BaseForm
        :members:
