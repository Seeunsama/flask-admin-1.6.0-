``flask_admin.form.upload``
===========================

.. automodule:: flask_admin.form.upload

	.. autoclass:: FileUploadField
		:members: __init__

	.. autoclass:: ImageUploadField
		:members: __init__

	.. autoclass:: FileUploadInput
	.. autoclass:: ImageUploadInput
